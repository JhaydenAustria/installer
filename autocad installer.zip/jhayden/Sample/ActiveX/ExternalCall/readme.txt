ExternalCall.DVB

This demo shows how to communicate with code written by an external application such as Visual Basic 6.0.
A simple function that calculates the volume of a cube was written in VB6, and saved in the form of a DLL.  We
use AutoCAD VBA to pass data into the DLL function and display the result.  Before running the demo you 
must use RegSvr32.EXE to register the ExternalFunction.DLL file.
