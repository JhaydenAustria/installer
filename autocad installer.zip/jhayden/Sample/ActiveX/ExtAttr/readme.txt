'      AutoCAD 2000
'
'      Extract Attributes via ActiveX Automation.
'
'      Copyright (C) 1997, 1999 by Autodesk, Inc.
'
'      Permission to use, copy, modify, and distribute this software
'      for any purpose and without fee is hereby granted, provided
'      that the above copyright notice appears in all copies and
'      that both that copyright notice and the limited warranty and
'      restricted rights notice below appear in all supporting
'      documentation.
'
'      AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
'      AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
'      MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC.
'      DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
'      UNINTERRUPTED OR ERROR FREE.
'
'      Use, duplication, or disclosure by the U.S. Government is subject to
'      restrictions set forth in FAR 52.227-19 (Commercial Computer
'      Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
'      (Rights in Technical Data and Computer Software), as applicable.


ExtrAttributes
----------------

In this sample, AutoCAD block attribute information is extracted from  block references and put into
an excel spreadsheet.

Open the Attrib.dwg drawing in AutoCAD, then start excel file by double clicking it.

Note that this sample expects the drawing for which you want to extract attributes to be currently open.

From the Excel Tools menu, pick Macro -> Macros.  

In the Macro list, select Extract, then AutoCAD will be accessed, the spread sheet with fill with attribute
data. 

When done, close the Excel spreadsheet first.

This sample may not run on a minimally configured computer due to the overhead required when running both AutoCAD
and MS Execl at the same time.

