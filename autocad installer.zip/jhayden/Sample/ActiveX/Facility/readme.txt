   AutoCAD 2000

   Facility ActiveX Automation Sample.

   Copyright (C) 1997, 1999 by Autodesk, Inc.

   Permission to use, copy, modify, and distribute this software in
   object code form for any purpose and without fee is hereby granted,
   provided that the above copyright notice appears in all copies and 
   that both that copyright notice and the limited warranty and
   restricted rights notice below appear in all supporting '   documentation.

   AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS. 
   AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
   MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC.
   DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
   UNINTERRUPTED OR ERROR FREE.

   Use, duplication, or disclosure by the U.S. Government is subject to 
   restrictions set forth in FAR 52.227-19 (Commercial Computer
   Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
   (Rights in Technical Data and Computer Software), as applicable. '



This program demonstrates how to connect AutoCAD to a database using ActiveX Automation, the program file EXE
was created in MS Visual Basic 6.0.

This program requires that a few VB6 DLL's be installed on your system. Unless these are on your system
you will need to run the setup program which is in the .\ACAD2000\Sample\ActiveX\Facility\Setup directory. 
The setup program should by default place the Facility program in the .\ACAD2000\Sample\ActiveX\Facility\
subdirectory, if not please use that location.

You can remove the Facilty program and all supporting files from your system by running Add/Remove Programs
in the control panel.

The facilities layout is shown in the drawing file Facility.DWG.

The associated data is contained in the Microsoft Access file DB1.MDB.

Create a backup copy of the original sample files, since database files may get corrupted easily.

You may want to position the AutoCAD screen and zoom if necessary such that it does not overlap the
Facility Database dialog box.

Start the program by double clicking the facility.exe file.

Connect to AutoCAD. If AutoCAD is open, the program  connects to the running copy 
of AutoCAD. Otherwise, it starts a new AutoCAD session and opens the facility.dwg file.
The prompts are shown in the status bar.

SQL Search:
===========

To do an SQL query, type in the expression in the box next to the button and click the SQL 
Search button.. For example, to search all record which relate to Room 101, type:

		Select * From Inventry Where Room='101'

Note that once you do a SQL query, the recordset changes to the recordset matching the query. 
To return to the default recordset, click the Clear SQL button. 

Clear SQL Button: 
=================

Resets the recordset to default.

Cancel Button:
==============

Cancels the last transaction.  

End:
====

Ends the program.


Show Record Button:
===================

When you pick the show button, the program prompts you to pick an item on the AutoCAD screen. 
Pick any  object, and it�s associated Microsoft Access record is shown on the screen.
Now, Edit and  Remove buttons are enabled that allow you to edit the record or remove the object and record.


Edit button:
============

It allows you to edit the displayed record. After editing the record, click the Apply 
button to complete the transaction.

Remove record:
==============
It allows you to remove the displayed record from Microsoft Access database and the
associated block from AutoCAD.  The drawing is saved immediately after removing the record.  
To disable saving the drawing, comment out the following line in cmdApply_Click subroutine:
 doc.Save

New Record:  
===========

If an item is picked in AutoCAD for which there is no associated record, then
you can use the New record button to add a new record. The program clears all the boxes on 
the dialog box and allows you to enter the information for the selected object. This information is
then stored in the Microsoft Access database when you click the Apply button.

Link Data: 
==========
This button allows you to link an object with a record.  All the records are currently linked.

Highlight Object: 
=================
It allows you to highlight/dehighlight the object that corresponds to the current record.

Known problems:
===============
Transaction processing is not enabled
Only basic error handling is supported in this demonstration program.
The sample files and the directory in which these files reside must not be Read-only.
If you delete any blocks from facility.dwg without deleting it using the facility application, a crash
may result.


