VBAIDE menu sample will do 2 things:

1. Creates a right docked toolbar with the following buttons in AutoCAD:
   vbarun, vbaload, vbaman, vbaide, vbaopt
   (note the bitmaps are supplied as a separate bmp files)

2. Customizes VBAIDE by creating the following 6 new menu items:
   File>New 
   File>Open
   File>Close
   AutoCAD>VBA Manager
   AutoCAD>VBA Macros
   AutoCAD>VBA Options

In order to activate this sample, you need to copy the ACAD.DVB file to the ACAD2000
subdirectory and then start AutoCAD. The ACAD.DVB file will autoload when AutoCAD is started.
When the ACADStartup in ACAD.DVB is run it will load the Custom_Menu.DVB, and run the  
CreateVBAToolBar, and VBAIDE_Customization macros in it.

There are several ways to run the code in the Acad.DVB file, a few are:

1) either start the VBAIDE, and it will autorun OR
2) execute the following lisp code from the either a S::STARTUP function in Acad.LSP,
or from the AutoCAD command line: (command "_.-VBARUN" ACADStartup)
3) Type -VBARUN at the AutoCAD command prompt.

In order to run this sample code, the relative paths in the macros expect this sample to be 
installed below the AutoCAD 2000 directory in the .\Sample\VBA\VBAIDEmenu.


Limitations:

AutoCAD>VBA Macros & File>Open menu items will not work when AutoCAD is in 0 Document state.
The VBA IDE menu items might stop working in certain scenarios. You need to run the
VBAIDE_Customization again to make them work.
