                       AutoCAD 2000 VBA                     
                      Sample Files Readme

Introduction
------------

  The following samples were developed by the programmers and testers on the
  AutoCAD VBA team.  These samples were developed to test functionality 
  and as such, may not represent best practices VBA programming style 
  and techniques. We welcome your comments.

Loading a sample project
------------------------

  Use the AutoCAD VBALOAD command or the AutoCAD VBA menu item to load a
  sample VBA project.  To run a VBA macro from within AutoCAD, use the 
  AutoCAD VBARUN command or the AutoCAD VBA/Run Macro... menu.  You will
  need to select the "Module1" code module and then the first macro name
  in the macro drop down list to run the sample.

  The project descriptions are listed below alphabetically.    


ATTEXT.DVB
----------

  This sample requires the Office97 programs: MS Excel, Word, Graph, and Chart to
  run. Load the Attrib.dwg drawing before running the sample.  The sample will send
  the attribute data in the drawing to an Excel spread sheet and will start a Word
  document named C:\demo.doc.

  You must have the Office97 programs: Excel, Word, Graph, and Chart loaded on your
  system, and your Excel and Word must be checked in the VBA IDE type library
  References settings for this project to compile and run. If you get errors
  when you try to run the sample, go into the VBA IDE and start the
  Tools/references dialog Uncheck any type libraries that are labeled "MISSING"
  and check the type library versions of Excel and Word that are on your system.

ACAD_CG.DVB
-----------

  This project demonstrates several Automation API's all run from a VBA dialog:

	 1) AutoCAD window location and resizing via Application Properties.
	 2) Creating a New Drawing with the Document New Method
	 3) Drawing simple objects
	 4) Querying and modifying object Properties
	 5) Prompting for User Input
	 6) Selection Sets, and the Selection Set Object
	 7) Preferences Properties
	 8) Creating Layers, and the Layers Object
	 9) Plotting a Drawing to a File with the Plot Object
	10) Creating and Scaling Paperspace Viewports
	11) Calculating user input distance via the Utility Object
	12) Attaching and retrieving Xdata, via the Get/SetXdata Methods
 
BLOCKREPLACE.DVB
----------------
  This demo allows the user to replace block references in the current drawing
  Modelspace.  Block References can be replaced as a group (Change all of one
  Block type to another Block type), or replaced individually from the current
  selection set.  If replacing from the current selection set, you must create
  an active selection set in the drawing before running the demo.  Certain
  properties of the Block References being replaced can be preserved, or they can
  be overwritten with new values.


CHPLYWID.DVB
------------

  This sample will change the width of all polylines in a drawing.  Draw
  some polylines before running the sample.

CNTRLINE.DVB
------------

  This sample prompts at the command line and adds center lines to
  circles and arcs.  Draw some circles, arcs, and lines before running
  the sample.

DRAWLALT.DVB
-----------

  This is the same sample as drawline.dvb but it uses the ThisDrawing
  object unique to VBA instead of the more common CreateObject method.
  Apps written with this technique can show better performance and also
  will work correctly with multiple copies of AutoCAD running, but the
  code is less portable to standalone VB environments.

DRAWLINE.DVB
------------

  This sample uses a VBA form (dialog box) to draw a line.

EXAMPLE_CODE.DVB
----------------

A VBA project containing boilerplate example code for all methods and properties.


EXAMPLE_EVENTS.DVB
------------------

  A VBA project containing the example code for all events. Note that once
  Events.dvb is loaded and enabled, all the events become enabled! There could be
  many message boxes flying as long as the project is loaded. This fires all the
  drawing events into separate message boxes.


EXCELLINK.DVB
-------------

   This demo shows how to pass data between AutoCAD and an external application such
   as Excel. This demo creates an Excel spreadsheet that contains a bill of materials (BOM)
   for the current drawing.  The bill of materials can then be edited in Excel and the
   data from the Excel Workbook can then be used to update the billing information stored
   in the drawing. 

   To run this demo you need to have Excel installed and will need to preload the Attrib.dwg
   sample drawing.  This drawing contains a table of attribute information used to create
   the BOM.  After loading the drawing, run the ExcelLink_Startup macro.  To send the drawing
   data to Excel, you will use the 'Export...' button on the UserForm.  

   Once the data is in Excel, you may change the data in Excel and update the information in
   the drawing table by using the 'Import..." button on the UserForm.  The data headers 
   contained in the first row of the BOM Worksheet are read-only from the drawing.  

   * Note: Before you update the drawing with the data in Excel, make sure to have the Workbook
   with the AutoCAD bill of materials loaded and set as the active Workbook.  Also, the sample
   will wait for any changes to Excel data to be commited before proceeding with the update.
   If you changed the value in a cell, make sure to move from the cell or press Enter to commit
   the change before updating.

IBEAM3D.DVB
-----------
   This sample dynamically creates a 3d solid representing an I-beam which is constructed from
   input parameters adjusted by mathematical calculations based on Moment of Inertia, and
   Section Modulus values for the beam.

MAP2GLOBE.DWG
-------------

   Embedded VBA macro generates 3d Polylines onto a Sphere from 2d polylines.


MENU.DVB
-----------

   This sample demonstrates the new MenuGroup and MenuBar ActiveX API's.

OBJECTTRACKER.DVB
-----------------

   This demo shows how to attach persistent information to AutoCAD objects using XRecordData.
   When a user modifies an object in a drawing or performs a command with this macro loaded,
   information is stored in a special Dictionary containing an XRecord.  Start the Run_Sample
   macro and select an object to view its tracking information, or select the drawing background
   (no objects selected) to view tracking information for the drawing.

SAVEASR12.DVB
-------------

   This VBA sample will call a separately registered application (Convert) which exposes an
   ActiveX Object that allows any Automation client to batch process AutoCAD 2000 format drawing files
   to the R12 DWG format via automation.

   When run, the SaveAsR12 sample requires the user to type in the Directory location of the 
   source dwg files, and the target directory location for the R12 format files. The user
   can then select from a list box, the files that they wish to convert. Once that is done, the
   macro calls the convert program to process the file(s) selected.

   The Convert application is ONLY available when the AutoCAD Migration Assistance has been
   installed. The Convert program is normally installed in it's own subdirectory under AutoCAD 2000:
   .\ACAD2000\Migration\Convert. There is a separate ReadMe (CONVERT.TXT) which covers important 
   information about using the Convert Program.

   If you attempt to run the SaveAsR12 macro, and you get either a warning dialog about:

     1) The Convert application is not registered, or Cannot Create Object.
     2) The chr function is generating a comple error, Can't find project or library.

   Then install the Migration Assistance tools.

     3) R14 fonts.

   Then copy ALL the R14 SHX fonts into the .\migration\convert\support directory.

TOWER.DWG
---------

   Electrical Power Transmission Tower Calculator.

   Begin by loading the Tower.dwg drawing, Select Enable Macros in the dialog if prompted, and
   then run the

   Start_Tower_Application macro that is embedded in the dwg file.

   The macro is correctly run by selecting the tabs from left to right. In each tab
   page use the control(s) available, before moving on to the next tab selection.

   You may wish to move the main dialog box (the top left or lower right corner of the screen
   is recommended), to be able to see the results of each program option you select.

   This sample will draw a 2D Electrical Power Transmission tower, and can compute tables of
   weights and foundation reactions. It will also do a stress analysis on the tower structure,
   and display the deformed tower for a given set of loads. The forces in each member can be
   queried interactively.

   The analysis module is quite general, so the user can modify the shape or size of the tower,
   or can change the values of the materials or cross sections of the bars, or even change the
   position, direction or value of the applied loads. 

   A set of 8 blocks are defined inside the dwg, and are provided to place different node loads.

   (FXPT, FXPC, FXNT, FXNC, FYPT, FYPC, FYNT, FYNC).

   where:

   F=Nodal Force, X=on X axis, Y=on Y axis, P=Positive, N=Negative, T=Tension, C=Compresion

   Once the structure model is complete, the user should run the Stress analysis using the Tab
   "Deformation".

   For each stress analysis that its run, the program generates a text file named "results.txt"
   with node displacements and bar forces. The "results.txt" file is created in the same folder
   where the tower.dwg resides.

  The source code is commented in Spanish. 

TXTHT.DVB
---------

   This sample will change the height of all text in a drawing.  You will
   need to insert some text in a new drawing to see the text height change.

